package com.main.java.com.praktikum.main;

import javafx.application.Application;
import javafx.stage.Stage;
import com.main.java.com.praktikum.gui.LoginPane;

public class LoginSystem extends Application {
    @Override
    public void start(Stage primaryStage) {
        new LoginPane().start(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}