package com.main.java.com.praktikum.data;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Item {
    private final StringProperty nim;
    private final StringProperty nama;
    private final StringProperty status;

    public Item(String nim, String nama, String status) {
        this.nim = new SimpleStringProperty(nim);
        this.nama = new SimpleStringProperty(nama);
        this.status = new SimpleStringProperty(status);
    }

    public StringProperty nimProperty() { return nim; }
    public StringProperty namaProperty() { return nama; }
    public StringProperty statusProperty() { return status; }
}