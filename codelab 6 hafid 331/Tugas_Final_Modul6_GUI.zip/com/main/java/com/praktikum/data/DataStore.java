package com.main.java.com.praktikum.data;

import java.util.Arrays;
import java.util.List;

public class DataStore {
    public static List<Item> getItems() {
        return Arrays.asList(
            new Item("20231001", "Andi", "Aktif"),
            new Item("20231002", "Budi", "Cuti"),
            new Item("20231003", "Citra", "Lulus")
        );
    }
}