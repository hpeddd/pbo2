package com.main.java.com.praktikum.gui;

import com.main.java.com.praktikum.data.DataStore;
import com.main.java.com.praktikum.data.Item;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminDashboard {
    public void start(Stage stage) {
        TableView<Item> table = new TableView<>();
        table.setItems(FXCollections.observableArrayList(DataStore.getItems()));

        TableColumn<Item, String> nimCol = new TableColumn<>("NIM");
        nimCol.setCellValueFactory(cellData -> cellData.getValue().nimProperty());

        TableColumn<Item, String> namaCol = new TableColumn<>("Nama");
        namaCol.setCellValueFactory(cellData -> cellData.getValue().namaProperty());

        TableColumn<Item, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(cellData -> cellData.getValue().statusProperty());

        table.getColumns().addAll(nimCol, namaCol, statusCol);

        Button logoutBtn = new Button("Logout");
        logoutBtn.setOnAction(e -> new LoginPane().start(stage));

        VBox root = new VBox(10, new Label("Dashboard Admin"), table, logoutBtn);
        root.setPadding(new Insets(20));
        stage.setScene(new Scene(root, 500, 400));
        stage.setTitle("Admin Dashboard");
        stage.show();
    }
}