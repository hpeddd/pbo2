package com.main.java.com.praktikum.gui;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MahasiswaDashboard {
    public void start(Stage stage) {
        VBox root = new VBox(10, new Label("Halo Mahasiswa!"));
        root.setPadding(new javafx.geometry.Insets(20));
        stage.setScene(new Scene(root, 300, 200));
        stage.setTitle("Dashboard Mahasiswa");
        stage.show();
    }
}