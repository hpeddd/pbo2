package com.main.java.com.praktikum.gui;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.main.java.com.praktikum.gui.AdminDashboard;
import com.main.java.com.praktikum.gui.MahasiswaDashboard;

public class LoginPane {
    public void start(Stage stage) {
        TextField username = new TextField();
        PasswordField password = new PasswordField();
        ComboBox<String> roleBox = new ComboBox<>();
        roleBox.getItems().addAll("Admin", "Mahasiswa");
        roleBox.setValue("Mahasiswa");

        Button loginBtn = new Button("Login");
        Label message = new Label();

        loginBtn.setOnAction(e -> {
            String user = username.getText();
            String pass = password.getText();
            String role = roleBox.getValue();

            if (role.equals("Admin") && user.equals("admin") && pass.equals("admin")) {
                new AdminDashboard().start(stage);
            } else if (role.equals("Mahasiswa") && user.equals("mahasiswa") && pass.equals("123")) {
                new MahasiswaDashboard().start(stage);
            } else {
                message.setText("Login gagal!");
            }
        });

        VBox root = new VBox(10, new Label("Username:"), username,
                new Label("Password:"), password,
                new Label("Login sebagai:"), roleBox, loginBtn, message);
        root.setPadding(new Insets(20));

        Scene scene = new Scene(root, 350, 300);
        stage.setScene(scene);
        stage.setTitle("Login System");
        stage.show();
    }
}